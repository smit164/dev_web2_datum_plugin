<?php

namespace Ilovepdf\Exceptions;

class TaskException extends \Exception
{

}
