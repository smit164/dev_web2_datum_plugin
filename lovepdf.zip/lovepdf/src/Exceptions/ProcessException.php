<?php

namespace Ilovepdf\Exceptions;

class ProcessException extends ExtendedException {

}
