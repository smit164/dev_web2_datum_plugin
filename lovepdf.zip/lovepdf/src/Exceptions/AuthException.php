<?php

namespace Ilovepdf\Exceptions;

class AuthException extends ExtendedException
{

}
