<?php

namespace Ilovepdf\Exceptions;

class UploadException extends ExtendedException {

}
