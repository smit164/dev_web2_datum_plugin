<?php

namespace Ilovepdf\Exceptions;

class PathException  extends \Exception {

}
