Changelog
---------

v1.0.11

* Bug AuthException warning

v1.0.10

* Remove unused vars
* Add try_pdf_repair
* Correct sample files typos

v1.0.9

* Add params check
* Remove unused classes

v1.0.8

* bug on response codes

v1.0.7

* Add Pdf to Pdf-A tool

v1.0.6

* fix warning method signature

v1.0.5

* Add library version
* bug fixes

v1.0.4

* added deleteFile Method

v1.0.3

* Add delete method for tasks
* Add getStatus method for tasks