<?php

namespace Ilovepdf\Exceptions;

class StartException  extends \Exception {

}
