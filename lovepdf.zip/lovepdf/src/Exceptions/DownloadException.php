<?php

namespace Ilovepdf\Exceptions;

class DownloadException extends ExtendedException {

}
